# HD Voxel Hair with Chain Physics (NeoForge 26.3)

Chunky, Minecraft-style hair for the player head, built from blocks like a hand-made
Blockbench model, with a 512x512 pixel-art texture and per-lock chain physics.

The style is short, layered and messy:
- four chunky bangs swept across the forehead, with short wisps between them
- a longer lock framing one side of the face
- a textured crown swept back
- flicks above the ears and locks in front of them
- an upper and lower layer at the back, ending in a pointed nape
- a cowlick that bounces

![preview](previews/preview.png)

`previews/physics.gif` shows the physics: idle, sprint, stop, a snap turn, looking down, then
looking up.

## What's in here

| Path | What it is |
| --- | --- |
| `src/main/java/com/kyrpton/superman/client/hair/` | The code (6 classes) |
| `src/main/resources/assets/superman/models/hair/messy_hair.obj` | The model: 118 blocks, 708 faces |
| `src/main/resources/assets/superman/models/hair/messy_hair_rig.json` | Physics for the 107 moving blocks |
| `src/main/resources/assets/superman/textures/entity/hair/messy_hair.png` | 512x512 texture, 4 texels per model pixel |
| `blender/` | OBJ + MTL + texture together, for Blender or Blockbench |
| `tools/generate_hair.py` | Rebuilds the model, texture and rig from code (needs Pillow) |
| `tools/preview.py` | Renders the previews, running the same physics as the mod (needs numpy, Pillow) |

## Installing into the Superman mod

1. Copy the `src` folder into the mod project (it only adds files; if you used the first hair
   version, these replace it).
2. Run `./gradlew runClient`. Every player gets the hair.

Everything is client-only and registers itself, so nothing else needs changing.

Choose who has hair, and tint it, from your client code:

```java
HairClientEvents.hairFilter = id -> playersWithHair.contains(id);
HairClientEvents.hairColour = id -> 0xFFFFE0A0; // ARGB; multiplies the texture
```

## How the physics works

Each lock is a chain of 3 to 4 blocks, and every block is a bone that swings relative to the
one above it. That lets locks bend and ripple instead of swinging as stiff pieces. Each tick,
every bone is pulled toward a target angle by a damped spring:

| Setting | Effect |
| --- | --- |
| `drag` | Moving makes locks trail behind; falling lifts them a little. |
| `gravity` | Looking up or down, or a parent block swinging, makes locks hang toward the ground. |
| `inertia` | Turning or speeding up pushes locks, so they overshoot and settle. |
| `whip` | A block lags behind its parent's movement, so motion ripples down to the tip. |
| `stiffness`, `damping` | How firmly a block returns to rest, and how fast wobbling dies down. Tips are softer than roots. |
| `xMin`, `xMax`, `zMin`, `zMax` | Swing limits in degrees, worked out by the generator so no lock can swing into the head or face. |

Swings are blended between ticks, so motion stays smooth at any frame rate.

Each lock type has its own feel: the crown is stiff, the bangs are medium, and the back,
nape and cowlick are the loosest. To tune them, edit `PRESETS` in `tools/generate_hair.py`
and rerun it, or edit the rig JSON directly.

## Editing the look

The model is generated from code, so the quickest changes are in `tools/generate_hair.py`:

- `build_locks()` lists every lock: root position, direction, bend, length and width.
- `PALETTE` holds the nine hair shades, dark to light. Recolour the hair here.
- `DENSITY` is the second command-line argument: 4 is the default, 2 gives a chunkier vanilla look.

```bash
python3 tools/generate_hair.py out 4 && python3 tools/preview.py out out
```

Then copy the files from `out/` into the resource folders above.

To hand-edit in Blender or Blockbench, use `blender/`. OBJ units are Minecraft pixels:
- The head is the box `(-4, 0, -4)` to `(4, 8, 4)`.
- +Y is up, -Z is the face, and +X is the character's left.
- Each block is its own object named `<lock>_<n>`, and its bone's `pivot` in the rig file is
  the joint at the start of that block.

## Before you build

This code targets the Minecraft 26.3 / NeoForge 26.3 rendering API (render states and
`SubmitNodeCollector`), but it has **not been compiled yet**. A few names moved between recent
versions. If the build reports a missing symbol, these are the likely spots, in `HairLayer` and
`HairClientEvents`:

- `PlayerModel` and `AvatarRenderState` packages (auto-import usually fixes these)
- the `AvatarRenderState.id` and `isInvisible` fields
- `RenderTypes.entityCutoutNoCull`
- `EntityRenderersEvent.AddLayers#getSkins` / `#getPlayerRenderer`
