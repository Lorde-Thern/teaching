#!/usr/bin/env python3
"""Textured preview of the hair on a plain Minecraft-style player, plus a physics animation.

The physics here is a straight port of HairPhysics.java, so the GIF shows what the mod does.

Usage: python3 preview.py <assets_dir> <out_dir>
Writes preview.png (four views) and physics.gif.
"""
import json
import math
import os
import sys

import numpy as np
from PIL import Image

ASSETS, OUT = sys.argv[1], sys.argv[2]
NAME = "messy_hair"
tex = np.asarray(Image.open(os.path.join(ASSETS, NAME + ".png")).convert("RGBA"))
TH, TW = tex.shape[:2]

# ------------------------------------------------------------------ load OBJ
objects = {}   # name -> list of (positions[4], uvs[4], normal)
order = []
V, T, N = [], [], []
cur = None
for line in open(os.path.join(ASSETS, NAME + ".obj")):
    p = line.split()
    if not p:
        continue
    if p[0] == "o":
        cur = p[1]; objects[cur] = []; order.append(cur)
    elif p[0] == "v": V.append([float(x) for x in p[1:4]])
    elif p[0] == "vt": T.append([float(x) for x in p[1:3]])
    elif p[0] == "vn": N.append([float(x) for x in p[1:4]])
    elif p[0] == "f":
        idx = [[int(x) - 1 for x in q.split("/")] for q in p[1:]]
        objects[cur].append((np.array([V[i[0]] for i in idx]), np.array([T[i[1]] for i in idx]),
                             np.array(N[idx[0][2]])))
rig = json.load(open(os.path.join(ASSETS, NAME + "_rig.json")))["groups"]
bone_names = list(rig.keys())
bone_index = {n: i for i, n in enumerate(bone_names)}

# ------------------------------------------------------------------ player body (original, plain)
SKIN = (222, 172, 134)
def solid_tex(colour):
    return colour

def cube(lo, hi, faces_colour):
    x0, y0, z0 = lo; x1, y1, z1 = hi
    c = lambda a, b, d: [x1 if a else x0, y1 if b else y0, z1 if d else z0]
    quads = {
        "front": [c(0,0,0), c(1,0,0), c(1,1,0), c(0,1,0)], "back": [c(1,0,1), c(0,0,1), c(0,1,1), c(1,1,1)],
        "left": [c(1,0,0), c(1,0,1), c(1,1,1), c(1,1,0)], "right": [c(0,0,1), c(0,0,0), c(0,1,0), c(0,1,1)],
        "top": [c(0,1,0), c(1,1,0), c(1,1,1), c(0,1,1)], "bottom": [c(0,0,1), c(1,0,1), c(1,0,0), c(0,0,0)],
    }
    out = []
    for k, q in quads.items():
        out.append((np.array(q, float), faces_colour.get(k, faces_colour["default"])))
    return out

FACE_PIX = [  # 8x8 face, rows top->bottom. s skin, w white, e eye, b brow, m mouth, h shadow
    "ssssssss",
    "ssssssss",
    "sbbssbbs",
    "swessews",
    "ssssssss",
    "ssshhsss",
    "sssmmsss",
    "ssssssss",
]
FACE_COL = {"s": SKIN, "w": (245, 245, 245), "e": (92, 58, 36), "b": (90, 52, 30),
            "m": (160, 92, 80), "h": (200, 150, 116)}
face_img = np.array([[FACE_COL[ch] + (255,) for ch in row] for row in FACE_PIX], np.uint8)

body = []
body += [("head", q, col) for q, col in cube((-4, 0, -4), (4, 8, 4), {"front": "FACE", "default": SKIN})]
body += [("torso", q, col) for q, col in cube((-4, -12, -2), (4, 0, 2), {"default": (40, 78, 170)})]
for sx in (-1, 1):
    x0 = 4 if sx > 0 else -8
    body += [("arm", q, col) for q, col in cube((x0, -12, -2), (x0 + 4, 0, 2), {"default": (40, 78, 170)})]

# ------------------------------------------------------------------ physics (port of HairPhysics.java)
SPEED_TO_ANGLE, TURN_PUSH = 2.0, 0.25
DEG = math.pi / 180

class Hair:
    def __init__(self):
        n = len(bone_names)
        self.x = np.zeros(n); self.z = np.zeros(n); self.vx = np.zeros(n); self.vz = np.zeros(n)
        self.ax = np.zeros(n); self.az = np.zeros(n)
        self.parent = [bone_index[rig[b]["parent"]] if rig[b]["parent"] else -1 for b in bone_names]
        self.last = None
        self.age = 0

    def tick(self, pos, yaw, pitch):
        self.age += 1
        if self.last is None:
            self.last = (pos, yaw, 0.0, 0.0)
        lp, lyaw, lf, ll = self.last
        dx, dz = pos[0] - lp[0], pos[2] - lp[2]
        yr = yaw * DEG
        fwd = -dx * math.sin(yr) + dz * math.cos(yr)
        left = dx * math.cos(yr) + dz * math.sin(yr)
        afwd, aleft = fwd - lf, left - ll
        turn = ((yaw - lyaw + 180) % 360 - 180) * DEG
        pr = pitch * DEG
        self.last = (pos, yaw, fwd, left)
        for i, b in enumerate(bone_names):
            r = rig[b]
            par = self.parent[i]
            sum_x = 0.0
            j = par
            while j >= 0:
                sum_x += self.x[j]; j = self.parent[j]
            sway = 0.03 * math.sin(self.age * 0.08 + i * 1.7)
            tx = r["drag"] * fwd * SPEED_TO_ANGLE - r["gravity"] * (pr + sum_x) + sway
            tz = r["drag"] * left * SPEED_TO_ANGLE + sway * 0.5
            px = r["inertia"] * afwd * SPEED_TO_ANGLE
            pz = r["inertia"] * (aleft * SPEED_TO_ANGLE - turn * TURN_PUSH)
            if par >= 0:
                px -= r["whip"] * self.ax[par]
                pz -= r["whip"] * self.az[par]
            nvx = self.vx[i] + r["stiffness"] * (tx - self.x[i]) - r["damping"] * self.vx[i] + px
            nvz = self.vz[i] + r["stiffness"] * (tz - self.z[i]) - r["damping"] * self.vz[i] + pz
            self.ax[i], self.az[i] = nvx - self.vx[i], nvz - self.vz[i]
            self.vx[i], self.vz[i] = nvx, nvz
            self.x[i] += nvx; self.z[i] += nvz
            lo, hi = r["xMin"] * DEG, r["xMax"] * DEG
            if self.x[i] < lo or self.x[i] > hi:
                self.x[i] = min(max(self.x[i], lo), hi); self.vx[i] = 0
            lo, hi = r["zMin"] * DEG, r["zMax"] * DEG
            if self.z[i] < lo or self.z[i] > hi:
                self.z[i] = min(max(self.z[i], lo), hi); self.vz[i] = 0

# ------------------------------------------------------------------ matrices
def m_t(v):
    m = np.eye(4); m[:3, 3] = v; return m
def m_rx(a):
    c, s = math.cos(a), math.sin(a); m = np.eye(4); m[1, 1] = c; m[1, 2] = -s; m[2, 1] = s; m[2, 2] = c; return m
def m_ry(a):
    c, s = math.cos(a), math.sin(a); m = np.eye(4); m[0, 0] = c; m[0, 2] = s; m[2, 0] = -s; m[2, 2] = c; return m
def m_rz(a):
    c, s = math.cos(a), math.sin(a); m = np.eye(4); m[0, 0] = c; m[0, 1] = -s; m[1, 0] = s; m[1, 1] = c; return m

def bone_mats(hair):
    """World matrices per bone in OBJ space (model angle a == OBJ rotation -a)."""
    mats = []
    for i, b in enumerate(bone_names):
        p = np.array(rig[b]["pivot"])
        local = m_t(p) @ m_rx(-hair.x[i]) @ m_rz(-hair.z[i]) @ m_t(-p)
        par = hair.parent[i]
        mats.append(mats[par] @ local if par >= 0 else local)
    return mats

# ------------------------------------------------------------------ rasteriser
LIGHT0 = np.array([0.2, 1.0, -0.7]); LIGHT0 /= np.linalg.norm(LIGHT0)
LIGHT1 = np.array([-0.2, 1.0, 0.7]); LIGHT1 /= np.linalg.norm(LIGHT1)

def light(n):
    l = 0.4 + 0.6 * min(1.0, max(0, n @ LIGHT0) * 0.6 + max(0, n @ LIGHT1) * 0.6)
    return l

def render(hair, view_yaw, view_pitch, head_pitch=0.0, size=520, ss=2, scale=24.0, centre_y=4.5):
    W = size * ss
    col = np.zeros((W, W, 3)); col[:] = (226, 232, 240)
    # soft vertical gradient background
    col *= np.linspace(1.03, 0.92, W)[:, None, None]
    zb = np.full((W, W), np.inf)
    view = m_rx(view_pitch * DEG) @ m_ry(view_yaw * DEG)
    head = m_rx(-head_pitch * DEG)   # looking down tilts the top of the head forward (-Z)
    sc = scale * ss

    def draw(pts, uvs, normal, mat, colour=None, face=False):
        hp = np.c_[pts, np.ones(len(pts))] @ mat.T
        n = (mat[:3, :3] @ normal); n /= np.linalg.norm(n) or 1
        vp = hp @ view.T
        vn = view[:3, :3] @ n
        shade = light(n)
        sx = W / 2 + vp[:, 0] * sc
        sy = W / 2 - (vp[:, 1] - centre_y) * sc
        sz = vp[:, 2]
        for tri in ((0, 1, 2), (0, 2, 3)):
            x = sx[list(tri)]; y = sy[list(tri)]; z = sz[list(tri)]
            x0, x1 = int(max(0, math.floor(x.min()))), int(min(W - 1, math.ceil(x.max())))
            y0, y1 = int(max(0, math.floor(y.min()))), int(min(W - 1, math.ceil(y.max())))
            if x0 > x1 or y0 > y1:
                continue
            den = (y[1] - y[2]) * (x[0] - x[2]) + (x[2] - x[1]) * (y[0] - y[2])
            if abs(den) < 1e-9:
                continue
            gx, gy = np.meshgrid(np.arange(x0, x1 + 1) + 0.5, np.arange(y0, y1 + 1) + 0.5)
            w0 = ((y[1] - y[2]) * (gx - x[2]) + (x[2] - x[1]) * (gy - y[2])) / den
            w1 = ((y[2] - y[0]) * (gx - x[2]) + (x[0] - x[2]) * (gy - y[2])) / den
            w2 = 1 - w0 - w1
            inside = (w0 >= -1e-6) & (w1 >= -1e-6) & (w2 >= -1e-6)
            if not inside.any():
                continue
            depth = w0 * z[0] + w1 * z[1] + w2 * z[2]
            sub = zb[y0:y1 + 1, x0:x1 + 1]
            mask = inside & (depth < sub - 1e-4)
            if not mask.any():
                continue
            if colour is not None:
                c = np.zeros(depth.shape + (3,)); c[:] = colour
            else:
                uv = uvs[list(tri)]
                u = w0 * uv[0, 0] + w1 * uv[1, 0] + w2 * uv[2, 0]
                v = w0 * uv[0, 1] + w1 * uv[1, 1] + w2 * uv[2, 1]
                img = face_img if face else tex
                h_, w_ = img.shape[:2]
                tx = np.clip((u * w_).astype(int), 0, w_ - 1)
                ty = np.clip(((1 - v) * h_).astype(int), 0, h_ - 1) if not face else np.clip((v * h_).astype(int), 0, h_ - 1)
                s = img[ty, tx]
                mask &= s[..., 3] > 127
                c = s[..., :3].astype(float)
            sub[mask] = depth[mask]
            col[y0:y1 + 1, x0:x1 + 1][mask] = c[mask] * shade

    ident = np.eye(4)
    for part, q, colour in body:
        mat = head if part == "head" else ident
        n = np.cross(q[1] - q[0], q[3] - q[0]); n /= np.linalg.norm(n)
        if colour == "FACE":
            draw(q, np.array([[1, 1], [0, 1], [0, 0], [1, 0]], float), n, mat, face=True)
        else:
            draw(q, None, n, mat, colour=np.array(colour, float))
    mats = bone_mats(hair)
    for name in order:
        mat = head @ (mats[bone_index[name]] if name in bone_index else ident)
        for pts, uvs, n in objects[name]:
            draw(pts, uvs, n, mat)
    img = Image.fromarray(np.clip(col, 0, 255).astype(np.uint8))
    return img.resize((size, size), Image.LANCZOS)


if __name__ == "__main__":
    os.makedirs(OUT, exist_ok=True)
    rest = Hair()
    views = [(0, 8, "front"), (-40, 12, "three-quarter"), (-90, 4, "side"), (180, 10, "back")]
    sheet = Image.new("RGB", (520 * 4, 520), "white")
    for i, (yaw, pitch, _) in enumerate(views):
        sheet.paste(render(rest, yaw, pitch), (520 * i, 0))
    sheet.save(os.path.join(OUT, "preview.png"))

    # Physics demo: stand, sprint, stop, whip the head round, look down, look up.
    hair = Hair()
    frames = []
    pos = [0.0, 0.0, 0.0]; yaw = 0.0; pitch = 0.0
    script = []
    for t in range(14): script.append((0.0, 0.0, 0.0))        # idle
    for t in range(22): script.append((0.28, 0.0, 0.0))       # sprint forward
    for t in range(18): script.append((0.0, 0.0, 0.0))        # stop
    for t in range(6): script.append((0.0, 30.0, 0.0))        # snap turn right
    for t in range(6): script.append((0.0, -30.0, 0.0))       # and back
    for t in range(18): script.append((0.0, 0.0, 0.0))
    for t in range(10): script.append((0.0, 0.0, 6.0))        # look down
    for t in range(14): script.append((0.0, 0.0, 0.0))
    for t in range(10): script.append((0.0, 0.0, -9.0))       # look up
    for t in range(14): script.append((0.0, 0.0, 0.0))
    for speed, dyaw, dpitch in script:
        yr = yaw * DEG
        pos = [pos[0] - math.sin(yr) * speed, 0.0, pos[2] + math.cos(yr) * speed]
        yaw += dyaw
        pitch = max(-60, min(60, pitch + dpitch))
        hair.tick(tuple(pos), yaw, pitch)
        # The camera follows the player, so draw with the body's own yaw removed.
        frames.append(render(hair, -50, 10, head_pitch=pitch, size=360))
    frames[0].save(os.path.join(OUT, "physics.gif"), save_all=True, append_images=frames[1:],
                   duration=50, loop=0, optimize=True)
    print("wrote preview.png and physics.gif,", len(frames), "frames")
