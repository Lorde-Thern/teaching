#!/usr/bin/env python3
"""Builds the HD voxel hair: model (OBJ), pixel-art texture (PNG) and physics rig (JSON).

Style: chunky Minecraft-style hair built from blocks. A layered cap sits just outside the head
(like a thick hat layer) and each lock of hair is a chain of tapered blocks. Every block is
its own OBJ object and its own physics bone, so locks bend along their length.

OBJ space (units = Minecraft pixels):
  origin = bottom-centre of the head (the neck pivot)
  +Y up, -Z = the face, +X = the character's left
  The head is the box x,z in [-4, 4], y in [0, 8].

Run:  python3 generate_hair.py <output_dir> [texels_per_pixel]
"""
import json
import math
import os
import random
import sys

from PIL import Image

OUT = sys.argv[1] if len(sys.argv) > 1 else "."
DENSITY = int(sys.argv[2]) if len(sys.argv) > 2 else 4   # texture pixels per model pixel
NAME = "messy_hair"
ATLAS = 512
random.seed(1337)


# ============================================================== vector helpers
def add(a, b): return (a[0] + b[0], a[1] + b[1], a[2] + b[2])
def sub(a, b): return (a[0] - b[0], a[1] - b[1], a[2] - b[2])
def mul(a, s): return (a[0] * s, a[1] * s, a[2] * s)
def dot(a, b): return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]
def cross(a, b): return (a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0])
def length(a): return math.sqrt(dot(a, a))
def norm(a):
    l = length(a) or 1.0
    return (a[0] / l, a[1] / l, a[2] / l)
def lerp3(a, b, t): return add(a, mul(sub(b, a), t))


def rot_x(p, a):
    c, s = math.cos(a), math.sin(a)
    return (p[0], p[1] * c - p[2] * s, p[1] * s + p[2] * c)


def rot_z(p, a):
    c, s = math.cos(a), math.sin(a)
    return (p[0] * c - p[1] * s, p[0] * s + p[1] * c, p[2])


# ============================================================== palette
# Warm auburn brown, darkest -> lightest. Shade index is a float; dithering picks the step.
PALETTE = [
    (34, 18, 12),
    (56, 30, 18),
    (78, 43, 24),
    (102, 58, 31),
    (126, 74, 40),
    (152, 93, 52),
    (180, 117, 68),
    (208, 148, 94),
    (232, 184, 132),
]
BAYER = [[0, 8, 2, 10], [12, 4, 14, 6], [3, 11, 1, 9], [15, 7, 13, 5]]


def shade_to_rgb(s, x, y):
    s = s + (BAYER[y % 4][x % 4] + 0.5) / 16 - 0.5
    i = max(0, min(len(PALETTE) - 1, int(math.floor(s + 0.5))))
    return PALETTE[i]


def hash01(*k):
    h = 2166136261
    for v in k:
        h = (h ^ (int(v) & 0xFFFFFFFF)) * 16777619 & 0xFFFFFFFF
    h ^= h >> 13
    h = h * 0x5bd1e995 & 0xFFFFFFFF
    h ^= h >> 15
    return (h & 0xFFFF) / 65535.0


# ============================================================== geometry store
HEAD_CENTRE = (0.0, 4.0, 0.0)
blocks = []   # every block becomes one OBJ object
bones = {}    # physics data for blocks that move


class Block:
    """A six-sided block: corners c[a][b][c] with a = along the length, b = across, c = depth."""

    def __init__(self, name, corners, painter, ctx):
        self.name = name
        self.c = corners
        self.painter = painter   # "cap" or "lock"
        self.ctx = ctx
        self.faces = []          # (4 points, uv rect, face info)

    def centre(self):
        pts = [self.c[a][b][c] for a in (0, 1) for b in (0, 1) for c in (0, 1)]
        return mul(tuple(map(sum, zip(*pts))), 1 / 8)


def frustum(start, end, side, depth, w0, t0, w1, t1):
    """Corners of a tapered block from `start` to `end`. side/depth are unit cross axes."""
    c = [[[None, None], [None, None]], [[None, None], [None, None]]]
    for a, (p, w, t) in enumerate(((start, w0, t0), (end, w1, t1))):
        for b in (0, 1):
            for d in (0, 1):
                c[a][b][d] = add(p, add(mul(side, (b - 0.5) * w), mul(depth, (d - 0.5) * t)))
    return c


def box(name, lo, hi, ctx=None):
    """Axis-aligned cap block. 'Length' runs along Y (top to bottom) so strands flow downward."""
    x0, y0, z0 = lo
    x1, y1, z1 = hi
    c = [[[None, None], [None, None]], [[None, None], [None, None]]]
    for a, y in enumerate((y1, y0)):
        for b, x in enumerate((x0, x1)):
            for d, z in enumerate((z0, z1)):
                c[a][b][d] = (x, y, z)
    blk = Block(name, c, "cap", ctx or {})
    blocks.append(blk)
    return blk


# ============================================================== the cap
def build_cap():
    # Layers sit at slightly different offsets so no two faces share a plane (no z-fighting).
    box("cap_top",        (-4.70, 7.55, -4.70), (4.70, 8.95, 4.70))
    box("cap_top_puff",   (-3.90, 8.85, -3.40), (3.70, 9.75, 3.90))
    box("cap_back",       (-4.62, 1.40, 3.95),  (4.62, 7.60, 4.78))
    box("cap_back_low",   (-3.60, 0.30, 4.05),  (3.60, 1.50, 4.70))
    for sx, tag in ((1, "l"), (-1, "r")):
        lo_x, hi_x = (3.92, 4.66) if sx > 0 else (-4.66, -3.92)
        box(f"cap_side_{tag}_front", (lo_x, 5.30, -4.60), (hi_x, 7.62, -0.40))
        box(f"cap_side_{tag}_back",  (lo_x * 1.004, 2.70, -0.60), (hi_x * 1.004, 7.64, 4.62))
        box(f"cap_temple_{tag}",     (lo_x * 0.99, 4.30, -1.90), (hi_x * 0.99, 5.40, -0.30))
    box("cap_fringe", (-4.64, 6.80, -4.80), (4.64, 7.62, -3.94))


# ============================================================== locks
PRESETS = {
    #          stiffness damping gravity drag inertia whip  maxDeg
    "bang":    (0.34, 0.30, 0.45, 0.80, 1.20, 0.55, 28),
    "crown":   (0.48, 0.36, 0.22, 0.45, 0.80, 0.45, 20),
    "side":    (0.26, 0.26, 0.75, 1.00, 1.40, 0.65, 34),
    "back":    (0.22, 0.24, 0.85, 1.25, 1.60, 0.70, 40),
    "nape":    (0.20, 0.22, 0.90, 1.35, 1.70, 0.75, 42),
    "cowlick": (0.16, 0.14, 0.30, 0.80, 2.40, 0.85, 50),
}


def penetration(p, margin=0.15):
    """How deep a point is inside the head box (with margin). <= 0 means outside."""
    return min(4 + margin - abs(p[0]), p[1] + margin, 8 + margin - p[1], 4 + margin - abs(p[2]))


def safe_limit(pivot, points, axis, sign, max_deg):
    """Largest swing (degrees, model convention) that does not push any point deeper into the head.

    The mod rotates in Minecraft model space (+Y down). A model-space angle `a` about X or Z is
    a rotation by `-a` in this +Y-up space, so that is what is tested here.
    """
    rest = [max(0.0, penetration(p)) for p in points]
    best = 0
    for deg in range(1, int(max_deg) + 1):
        a = -math.radians(deg) * sign
        for p, r in zip(points, rest):
            q = sub(p, pivot)
            q = rot_x(q, a) if axis == "x" else rot_z(q, a)
            if penetration(add(q, pivot)) > r + 0.02:
                return best
        best = deg
    return best


def lock(name, root, direction, bend, segs, kind, twist=0.0):
    """A lock of hair: a chain of tapered blocks.

    segs: list of (length, width, thickness) at the START of each block; the last block
    tapers to a narrow tip. `bend` is added to the direction a little more at each block.
    """
    d0 = norm(direction)
    out = norm(sub(root, HEAD_CENTRE))              # the broad side faces away from the head
    total = sum(s[0] for s in segs)
    joints = [root]
    dirs = []
    p = root
    for k, (ln, _, _) in enumerate(segs):
        d = norm(add(d0, mul(bend, (k + 1) / len(segs))))
        dirs.append(d)
        p = add(p, mul(d, ln))
        joints.append(p)

    s_list = ["%s_%d" % (name, k) for k in range(len(segs))]
    run = 0.0
    for k, (ln, w, t) in enumerate(segs):
        d = dirs[k]
        side = cross(d, out)
        if length(side) < 1e-3:
            side = cross(d, (0, 0, 1))
        side = norm(side)
        depth = norm(cross(side, d))
        if twist:
            ang = twist * (k + 1)
            side, depth = (add(mul(side, math.cos(ang)), mul(depth, math.sin(ang))),
                           add(mul(side, -math.sin(ang)), mul(depth, math.cos(ang))))
        if k + 1 < len(segs):
            w1, t1 = segs[k + 1][1], segs[k + 1][2]
        else:
            w1, t1 = max(0.35, w * 0.22), max(0.3, t * 0.35)
        overlap = 0.35 if k > 0 else 0.6                # blocks sink into the previous one
        start = sub(joints[k], mul(d, overlap))
        corners = frustum(start, joints[k + 1], side, depth, w, t, w1, t1)
        blk = Block(s_list[k], corners, "lock", {
            "t0": max(0.0, (run - overlap) / total), "t1": (run + ln) / total,
            "seed": hash01(len(blocks), 7) * 10, "kind": kind,
        })
        blocks.append(blk)
        run += ln

        st, dm, g, dr, inr, wh, mx = PRESETS[kind]
        fall = 1 - 0.14 * k                              # tips are softer than roots
        tip_points = joints[k + 1:]
        tip_points = tip_points + [corners[1][b][c] for b in (0, 1) for c in (0, 1)]
        lim = {}
        for axis in ("x", "z"):
            for sign, key in ((1, "Max"), (-1, "Min")):
                lim[axis + key] = sign * safe_limit(joints[k], tip_points, axis, sign, mx)
        bones[s_list[k]] = {
            "pivot": [round(v, 4) for v in joints[k]],
            "parent": s_list[k - 1] if k > 0 else None,
            "stiffness": round(st * fall, 3), "damping": round(dm * (0.85 + 0.15 * fall), 3),
            "gravity": g, "drag": dr, "inertia": round(inr * (1 + 0.2 * k), 3),
            "whip": wh if k > 0 else 0.0,
            "xMin": lim["xMin"], "xMax": lim["xMax"], "zMin": lim["zMin"], "zMax": lim["zMax"],
        }


def taper(n, length_, w, t, shrink=0.78):
    """Evenly split segment list: n blocks, total `length_`, shrinking width/thickness."""
    out = []
    for k in range(n):
        f = shrink ** k
        out.append((length_ / n * (1.08 - 0.06 * k), w * f, t * (0.9 ** k)))
    return out


def build_locks():
    # --- Bangs: four chunky locks swept toward the character's left (+X), ending above the eyes.
    bangs = [
        # x,    y,    length, width, sweep
        (-3.35, 7.70, 3.3, 2.9, 0.18),
        (-1.45, 7.85, 3.9, 3.1, 0.34),
        (0.55, 7.85, 3.6, 3.0, 0.50),
        (2.45, 7.70, 3.0, 2.8, 0.62),
    ]
    for i, (x, y, ln, w, sweep) in enumerate(bangs):
        lock(f"bang{i}", (x, y, -4.95), (sweep, -1.0, -0.22), (0.30, 0.10, 0.12), taper(3, ln, w, 1.2),
             "bang", twist=0.04 * (i - 1.5))
    # Short wisps between them for a layered fringe
    for i, x in enumerate((-2.45, -0.45, 1.55)):
        lock(f"wisp{i}", (x, 7.40, -4.92), (0.45, -1.0, -0.12), (0.2, 0.1, 0.08), taper(3, 2.1, 1.7, 0.8), "bang")
    # A longer lock framing the face on the character's left
    lock("frame", (3.95, 7.5, -4.6), (0.25, -1.0, -0.1), (0.15, 0.0, 0.1), taper(4, 4.6, 2.4, 1.1), "side")

    # --- Crown: messy spikes swept back, kept close to the head.
    crown = [
        ((-2.4, 9.3, -2.4), (-0.35, 0.55, 0.75), 3.0),
        ((0.2, 9.5, -2.6), (0.05, 0.62, 0.8), 3.2),
        ((2.6, 9.3, -2.2), (0.45, 0.5, 0.75), 2.9),
        ((-3.0, 9.1, 0.8), (-0.75, 0.35, 0.65), 2.8),
        ((3.1, 9.1, 0.9), (0.75, 0.35, 0.65), 2.7),
        ((-0.9, 9.6, 0.4), (-0.2, 0.55, 0.85), 3.3),
        ((1.5, 9.6, 1.0), (0.3, 0.5, 0.9), 3.1),
    ]
    for i, (root, d, ln) in enumerate(crown):
        lock(f"crown{i}", root, d, (0.0, -0.75, 0.35), taper(3, ln, 3.0, 1.5), "crown")

    # --- Sides: locks in front of the ears, and a flick above each ear.
    for sx, tag in ((1, "l"), (-1, "r")):
        lock(f"side{tag}0", (4.85 * sx, 6.4, -2.9), (0.08 * sx, -1.0, -0.1), (0.1 * sx, 0, -0.05),
             taper(3, 3.8, 2.5, 1.1), "side")
        lock(f"side{tag}1", (4.95 * sx, 6.6, -0.6), (0.18 * sx, -1.0, 0.1), (0.15 * sx, 0, 0.2),
             taper(3, 3.6, 2.7, 1.2), "side")
        lock(f"side{tag}2", (4.95 * sx, 6.3, 1.9), (0.22 * sx, -1.0, 0.3), (0.2 * sx, 0, 0.25),
             taper(3, 3.3, 2.7, 1.2), "side")
        lock(f"flick{tag}", (4.70 * sx, 8.6, -0.4), (0.8 * sx, 0.15, 0.45), (0.05 * sx, -0.8, 0.2),
             taper(3, 2.4, 2.4, 1.1), "crown")

    # --- Back: an upper layer over a lower layer, ending in a pointed nape.
    upper = [(-3.2, 7.3, -0.35), (-1.05, 7.5, -0.1), (1.05, 7.5, 0.1), (3.2, 7.3, 0.35)]
    for i, (x, y, sx) in enumerate(upper):
        lock(f"backup{i}", (x, y, 4.95), (sx, -0.9, 0.5), (0.0, -0.35, -0.35), taper(3, 4.0, 3.1, 1.3), "back")
    lower = [(-2.9, 4.3, -0.3), (-0.95, 4.0, -0.08), (0.95, 4.0, 0.08), (2.9, 4.3, 0.3)]
    for i, (x, y, sx) in enumerate(lower):
        lock(f"backlow{i}", (x, y, 4.95), (sx, -1.0, 0.22), (0.0, -0.1, -0.15), taper(3, 3.3, 2.7, 1.1), "back")
    for i, x in enumerate((-1.3, 0.0, 1.3)):
        lock(f"nape{i}", (x, 1.4, 4.85), (0.18 * (i - 1), -1.0, 0.15), (0, 0, -0.08),
             taper(3, 2.6 - abs(i - 1) * 0.6, 2.1, 0.9), "nape")

    # --- Cowlick: a thin lock on top that curls forward and bounces.
    lock("cowlick", (0.5, 9.7, -0.6), (0.1, 1.0, 0.2), (0.25, -1.4, -1.8), taper(4, 3.8, 1.2, 0.75, shrink=0.86), "cowlick")


# ============================================================== faces + atlas
FACE_DEFS = [
    # name, corner selector (a,b,c) for the 4 corners in u0v0,u1v0,u1v1,u0v1 order, kind
    ("b1", [(0, 1, 0), (0, 1, 1), (1, 1, 1), (1, 1, 0)], "long"),
    ("b0", [(0, 0, 1), (0, 0, 0), (1, 0, 0), (1, 0, 1)], "long"),
    ("c1", [(0, 0, 1), (0, 1, 1), (1, 1, 1), (1, 0, 1)], "long"),
    ("c0", [(0, 1, 0), (0, 0, 0), (1, 0, 0), (1, 1, 0)], "long"),
    ("a0", [(0, 0, 0), (0, 1, 0), (0, 1, 1), (0, 0, 1)], "root"),
    ("a1", [(1, 0, 1), (1, 1, 1), (1, 1, 0), (1, 0, 0)], "tip"),
]


class Packer:
    def __init__(self, size):
        self.size, self.x, self.y, self.row = size, 1, 1, 0

    def place(self, w, h):
        if self.x + w + 1 > self.size:
            self.x, self.y, self.row = 1, self.y + self.row + 2, 0
        if self.y + h + 1 > self.size:
            raise RuntimeError("texture atlas full; lower DENSITY or raise ATLAS")
        pos = (self.x, self.y)
        self.x += w + 2
        self.row = max(self.row, h)
        return pos


def build_faces():
    packer = Packer(ATLAS)
    for blk in blocks:
        centre = blk.centre()
        for fname, sel, kind in FACE_DEFS:
            pts = [blk.c[a][b][c] for a, b, c in sel]
            w_len = max(length(sub(pts[1], pts[0])), length(sub(pts[2], pts[3])))
            h_len = max(length(sub(pts[3], pts[0])), length(sub(pts[2], pts[1])))
            tw = max(1, int(round(w_len * DENSITY)))
            th = max(1, int(round(h_len * DENSITY)))
            n = face_normal(pts)
            fc = mul(tuple(map(sum, zip(*pts))), 0.25)
            if dot(n, sub(fc, centre)) < 0:   # make the face point out of its block
                pts = [pts[1], pts[0], pts[3], pts[2]]
                flip = True
                n = mul(n, -1)
            else:
                flip = False
            x, y = packer.place(tw, th)
            blk.faces.append({"pts": pts, "rect": (x, y, tw, th), "kind": kind, "normal": n, "flip": flip})


def face_normal(pts):
    n = (0.0, 0.0, 0.0)
    for i in range(len(pts)):
        a, b = pts[i], pts[(i + 1) % len(pts)]
        n = add(n, ((a[1] - b[1]) * (a[2] + b[2]), (a[2] - b[2]) * (a[0] + b[0]), (a[0] - b[0]) * (a[1] + b[1])))
    return norm(n)


# ============================================================== painting
CROWN = (0.4, 9.8, 1.4)   # the whorl the cap strands flow out from


def paint_lock_face(img, blk, face):
    x0, y0, w, h = face["rect"]
    ctx = blk.ctx
    t0, t1, seed = ctx["t0"], ctx["t1"], ctx["seed"]
    n = face["normal"]
    fc = mul(tuple(map(sum, zip(*face["pts"]))), 0.25)
    outward = dot(n, norm(sub(fc, HEAD_CENTRE)))
    strands = max(2, w // 3)
    for j in range(h):
        for i in range(w):
            u = (i + 0.5) / w
            if face["flip"]:
                u = 1 - u
            if face["kind"] == "long":
                t = t0 + (t1 - t0) * (j + 0.5) / h
                sc = u * strands + seed
                sid = int(math.floor(sc))
                frac = sc - sid
                s = 3.2 + 2.2 * t                         # dark roots, light tips
                s += (hash01(sid, int(seed * 100)) - 0.5) * 0.9
                s += 0.9 * outward - 0.3                  # outer side catches light
                s += 0.5 * n[1]                           # upward faces brighter
                if frac < 1.0 / 3 and w >= 4:
                    s -= 1.3                              # dark line between strands
                if i == 0 or i == w - 1:
                    s -= 1.1                              # outline along the edges
                if 0.22 < t < 0.42 and outward > 0.2 and hash01(sid, 99) > 0.35:
                    s += 1.9 * (1 - abs(t - 0.32) / 0.1)  # glossy shine band
                if t > 0.93:
                    s += 0.6
            elif face["kind"] == "tip":
                s = 5.6 - 0.8 * ((i == 0) or (i == w - 1) or j == 0 or j == h - 1)
            else:
                s = 1.4
            img.putpixel((x0 + i, y0 + j), shade_to_rgb(s, x0 + i, y0 + j) + (255,))


def paint_cap_face(img, blk, face):
    x0, y0, w, h = face["rect"]
    p00, p10, p11, p01 = face["pts"]
    n = face["normal"]
    for j in range(h):
        for i in range(w):
            u, v = (i + 0.5) / w, (j + 0.5) / h
            p = lerp3(lerp3(p00, p10, u), lerp3(p01, p11, u), v)
            rel = sub(p, CROWN)
            ang = math.atan2(rel[2], rel[0])
            dist = length((rel[0], 0, rel[2]))
            wobble = 0.35 * math.sin(dist * 0.9 + ang * 3)
            sc = (ang / (2 * math.pi)) * 46 + wobble
            sid = int(math.floor(sc))
            frac = sc - sid
            s = 3.0 + (p[1] - 4.5) * 0.32                 # lighter toward the top
            s += (hash01(sid, 5) - 0.5) * 0.9
            s += 0.45 * n[1]
            if frac < 0.3:
                s -= 1.2
            if n[1] > 0.5 and 2.6 < dist < 4.2 and hash01(sid, 77) > 0.3:
                s += 1.6 * (1 - abs(dist - 3.4) / 0.8)    # shine ring on top
            if n[1] < 0.5 and p[1] < 9:
                edge = min(v, 1 - v, u, 1 - u) * min(w, h)
                if v > 1 - 2.0 / h:
                    s -= 1.0                              # darker where the cap meets skin
            if n[1] < -0.5:
                s = 1.2                                   # underside
            img.putpixel((x0 + i, y0 + j), shade_to_rgb(s, x0 + i, y0 + j) + (255,))


def paint_atlas(path):
    img = Image.new("RGBA", (ATLAS, ATLAS), (0, 0, 0, 0))
    for blk in blocks:
        for face in blk.faces:
            (paint_cap_face if blk.painter == "cap" else paint_lock_face)(img, blk, face)
            # 1-texel gutter so filtering at the edges never picks up a neighbour
            x0, y0, w, h = face["rect"]
            for i in range(-1, w + 1):
                for j in (-1, h):
                    img.putpixel((x0 + i, y0 + j), img.getpixel((x0 + min(max(i, 0), w - 1), y0 + min(max(j, 0), h - 1))))
            for j in range(0, h):
                for i in (-1, w):
                    img.putpixel((x0 + i, y0 + j), img.getpixel((x0 + min(max(i, 0), w - 1), y0 + j)))
    img.save(path)


# ============================================================== writers
def write_obj(path):
    lines = [f"# {NAME}.obj",
             "# Units: Minecraft pixels. Origin: bottom-centre of the head. +Y up, -Z front, +X character's left.",
             "# One object per block. Objects named <lock>_<n> are physics bones (see the _rig.json).",
             f"mtllib {NAME}.mtl"]
    vo = to = no = 0
    for blk in blocks:
        lines += [f"o {blk.name}", f"usemtl {NAME}"]
        vs, ts, ns, fs = [], [], [], []
        for face in blk.faces:
            x0, y0, w, h = face["rect"]
            uv = [(x0, y0), (x0 + w, y0), (x0 + w, y0 + h), (x0, y0 + h)]
            if face["flip"]:
                uv = [uv[1], uv[0], uv[3], uv[2]]
            ns.append(face["normal"])
            idx = []
            for p, (u, v) in zip(face["pts"], uv):
                vs.append(p)
                ts.append((u / ATLAS, 1 - v / ATLAS))
                idx.append((vo + len(vs), to + len(ts), no + len(ns)))
            fs.append("f " + " ".join(f"{a}/{b}/{c}" for a, b, c in idx))
        lines += [f"v {x:.4f} {y:.4f} {z:.4f}" for x, y, z in vs]
        lines += [f"vt {u:.6f} {v:.6f}" for u, v in ts]
        lines += [f"vn {x:.4f} {y:.4f} {z:.4f}" for x, y, z in ns]
        lines += fs
        vo += len(vs); to += len(ts); no += len(ns)
    open(path, "w").write("\n".join(lines) + "\n")


if __name__ == "__main__":
    build_cap()
    build_locks()
    build_faces()
    os.makedirs(OUT, exist_ok=True)
    write_obj(os.path.join(OUT, f"{NAME}.obj"))
    open(os.path.join(OUT, f"{NAME}.mtl"), "w").write(
        f"newmtl {NAME}\nKd 1.0 1.0 1.0\nmap_Kd {NAME}.png\n")
    paint_atlas(os.path.join(OUT, f"{NAME}.png"))
    with open(os.path.join(OUT, f"{NAME}_rig.json"), "w") as f:
        json.dump({
            "_comment": "Physics per block. Objects not listed (the cap) never move. pivot is in OBJ units "
                        "(pixels, +Y up). Limits are degrees in Minecraft model space and were computed so "
                        "locks do not swing into the head. parent = the block this one hangs from.",
            "groups": bones}, f, indent=2)
    print(f"{len(blocks)} blocks ({len(bones)} moving), {sum(len(b.faces) for b in blocks)} faces, "
          f"atlas {ATLAS}x{ATLAS} at {DENSITY} texels/pixel")
