package com.kyrpton.superman.client.hair;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * A minimal Wavefront OBJ reader.
 *
 * <p>Reads {@code v}, {@code vt}, {@code vn}, {@code f} and {@code o}/{@code g} lines. Every
 * object or group becomes one {@link Group}, which is what the hair physics moves. Faces are
 * stored as quads: triangles repeat their last corner, and larger polygons are split into
 * triangles first. That matches Minecraft's entity render types, which draw quads.
 *
 * <p>Positions are converted from OBJ space (pixels, +Y up) to Minecraft model space
 * (1/16 block, +Y down) while loading, so rendering needs no further conversion.
 */
public final class ObjModel {
    /** One vertex: position (model space), texture coordinate and normal (model space). */
    public record Vertex(float x, float y, float z, float u, float v, float nx, float ny, float nz) {}

    /** A named part of the model. {@code quads} holds four vertices per quad. */
    public record Group(String name, List<Vertex> quads) {}

    private final Map<String, Group> groups;

    private ObjModel(Map<String, Group> groups) {
        this.groups = groups;
    }

    public Map<String, Group> groups() {
        return groups;
    }

    public static ObjModel read(Reader source) throws IOException {
        List<float[]> positions = new ArrayList<>();
        List<float[]> uvs = new ArrayList<>();
        List<float[]> normals = new ArrayList<>();
        Map<String, Group> groups = new LinkedHashMap<>();
        Group current = null;

        BufferedReader reader = new BufferedReader(source);
        String line;
        while ((line = reader.readLine()) != null) {
            line = line.strip();
            if (line.isEmpty() || line.startsWith("#")) continue;
            String[] p = line.split("\\s+");
            switch (p[0]) {
                case "v" -> positions.add(new float[] {
                        Float.parseFloat(p[1]) / 16f,
                        -Float.parseFloat(p[2]) / 16f, // OBJ is +Y up, Minecraft models are +Y down
                        Float.parseFloat(p[3]) / 16f});
                case "vt" -> uvs.add(new float[] {
                        Float.parseFloat(p[1]),
                        1f - Float.parseFloat(p[2])}); // OBJ has V=0 at the bottom of the image
                case "vn" -> normals.add(new float[] {
                        Float.parseFloat(p[1]),
                        -Float.parseFloat(p[2]),
                        Float.parseFloat(p[3])});
                case "o", "g" -> {
                    String name = p.length > 1 ? p[1] : "default";
                    current = groups.computeIfAbsent(name, n -> new Group(n, new ArrayList<>()));
                }
                case "f" -> {
                    if (current == null) {
                        current = groups.computeIfAbsent("default", n -> new Group(n, new ArrayList<>()));
                    }
                    Vertex[] corners = new Vertex[p.length - 1];
                    for (int i = 1; i < p.length; i++) {
                        corners[i - 1] = vertex(p[i], positions, uvs, normals);
                    }
                    addPolygon(current.quads(), corners);
                }
                default -> { } // mtllib, usemtl, s, ... are not needed
            }
        }
        return new ObjModel(groups);
    }

    private static Vertex vertex(String token, List<float[]> positions, List<float[]> uvs, List<float[]> normals) {
        String[] idx = token.split("/");
        float[] pos = positions.get(index(idx[0], positions.size()));
        float[] uv = idx.length > 1 && !idx[1].isEmpty() ? uvs.get(index(idx[1], uvs.size())) : new float[] {0, 0};
        float[] n = idx.length > 2 && !idx[2].isEmpty() ? normals.get(index(idx[2], normals.size())) : new float[] {0, -1, 0};
        return new Vertex(pos[0], pos[1], pos[2], uv[0], uv[1], n[0], n[1], n[2]);
    }

    /** OBJ indices start at 1, and negative indices count back from the end. */
    private static int index(String s, int size) {
        int i = Integer.parseInt(s);
        return i < 0 ? size + i : i - 1;
    }

    private static void addPolygon(List<Vertex> out, Vertex[] c) {
        if (c.length == 4) {
            out.add(c[0]); out.add(c[1]); out.add(c[2]); out.add(c[3]);
            return;
        }
        // Triangle fan; each triangle becomes a quad with a repeated corner.
        for (int i = 1; i + 1 < c.length; i++) {
            out.add(c[0]); out.add(c[i]); out.add(c[i + 1]); out.add(c[i + 1]);
        }
    }
}
