package com.kyrpton.superman.client.hair;

import org.joml.Matrix4f;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;

import net.minecraft.client.Minecraft;
import net.minecraft.client.model.player.PlayerModel;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.entity.state.AvatarRenderState;
import net.minecraft.client.renderer.rendertype.RenderType;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.client.renderer.texture.OverlayTexture;

/**
 * Draws the hair on a player's head. Each block is moved by its bone, and each bone is moved by
 * its parent, so locks bend along their length.
 */
public class HairLayer extends RenderLayer<AvatarRenderState, PlayerModel> {

    public HairLayer(RenderLayerParent<AvatarRenderState, PlayerModel> parent) {
        super(parent);
    }

    @Override
    public void submit(PoseStack poseStack, SubmitNodeCollector collector, int light,
                       AvatarRenderState state, float yRot, float xRot) {
        HairModel model = HairClientEvents.model();
        if (model == null || state.isInvisible || !HairClientEvents.hasHair(state.id)) return;

        float partialTick = Minecraft.getInstance().getDeltaTracker().getGameTimeDeltaPartialTick(false);
        RenderType renderType = RenderTypes.entityCutoutNoCull(model.texture());
        int colour = HairClientEvents.hairColour.applyAsInt(state.id);
        Matrix4f[] boneMatrices = boneMatrices(model, state.id, partialTick);

        poseStack.pushPose();
        // Move to the head bone so the hair follows head turns, sneaking, swimming and so on.
        getParentModel().getHead().translateAndRotate(poseStack);

        for (HairModel.Part part : model.parts()) {
            poseStack.pushPose();
            if (part.bone() >= 0) {
                poseStack.mulPose(boneMatrices[part.bone()]);
            }
            collector.submitCustomGeometry(poseStack, renderType,
                    (pose, consumer) -> draw(part.mesh(), pose, consumer, light, colour));
            poseStack.popPose();
        }
        poseStack.popPose();
    }

    /** Head-space transform of every bone: rotate about its pivot, then apply its parent's. */
    private static Matrix4f[] boneMatrices(HairModel model, int entityId, float partialTick) {
        var bones = model.bones();
        Matrix4f[] out = new Matrix4f[bones.size()];
        for (int i = 0; i < bones.size(); i++) {
            HairRig.Bone b = bones.get(i);
            Matrix4f local = new Matrix4f()
                    .translate(b.pivotX(), b.pivotY(), b.pivotZ())
                    .rotateX(HairPhysics.angleX(entityId, i, partialTick))
                    .rotateZ(HairPhysics.angleZ(entityId, i, partialTick))
                    .translate(-b.pivotX(), -b.pivotY(), -b.pivotZ());
            int parent = model.parent(i);
            out[i] = parent >= 0 ? new Matrix4f(out[parent]).mul(local) : local;
        }
        return out;
    }

    private static void draw(ObjModel.Group mesh, PoseStack.Pose pose, VertexConsumer consumer, int light, int colour) {
        for (ObjModel.Vertex v : mesh.quads()) {
            consumer.addVertex(pose, v.x(), v.y(), v.z())
                    .setColor(colour)
                    .setUv(v.u(), v.v())
                    .setOverlay(OverlayTexture.NO_OVERLAY)
                    .setLight(light)
                    .setNormal(pose, v.nx(), v.ny(), v.nz());
        }
    }
}
