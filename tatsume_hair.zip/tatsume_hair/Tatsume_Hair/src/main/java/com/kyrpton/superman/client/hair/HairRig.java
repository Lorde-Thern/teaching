package com.kyrpton.superman.client.hair;

import java.io.Reader;
import java.util.LinkedHashMap;
import java.util.Map;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

/**
 * Physics settings for each moving block of a hair model, read from {@code *_rig.json}.
 * Blocks that are not listed (the cap) stay still.
 */
public final class HairRig {
    /**
     * One bone. Pivots are in Minecraft model space (1/16 block, +Y down); angles in radians.
     *
     * @param parent    name of the block this one hangs from, or null for the root of a lock
     * @param stiffness how hard the block springs back to rest (0..1 per tick)
     * @param damping   how fast swinging dies down (0..1 per tick)
     * @param gravity   how much the block hangs toward the ground when the head tilts
     * @param drag      how far the block trails behind when moving
     * @param inertia   how hard the block swings when the head turns or speeds up
     * @param whip      how much this block lags behind its parent's swing (the "whip" in a lock)
     * @param xMin      swing limits; computed by the generator so locks never pass into the head
     */
    public record Bone(String parent,
                       float pivotX, float pivotY, float pivotZ,
                       float stiffness, float damping, float gravity,
                       float drag, float inertia, float whip,
                       float xMin, float xMax, float zMin, float zMax) {}

    private final Map<String, Bone> bones;

    private HairRig(Map<String, Bone> bones) {
        this.bones = bones;
    }

    public Bone bone(String group) {
        return bones.get(group);
    }

    public static HairRig read(Reader source) {
        JsonObject groups = JsonParser.parseReader(source).getAsJsonObject().getAsJsonObject("groups");
        Map<String, Bone> bones = new LinkedHashMap<>();
        for (var entry : groups.entrySet()) {
            JsonObject g = entry.getValue().getAsJsonObject();
            var pivot = g.getAsJsonArray("pivot");
            JsonElement parent = g.get("parent");
            bones.put(entry.getKey(), new Bone(
                    parent == null || parent.isJsonNull() ? null : parent.getAsString(),
                    pivot.get(0).getAsFloat() / 16f,
                    -pivot.get(1).getAsFloat() / 16f, // same OBJ -> model conversion as ObjModel
                    pivot.get(2).getAsFloat() / 16f,
                    g.get("stiffness").getAsFloat(),
                    g.get("damping").getAsFloat(),
                    g.get("gravity").getAsFloat(),
                    g.get("drag").getAsFloat(),
                    g.get("inertia").getAsFloat(),
                    g.has("whip") ? g.get("whip").getAsFloat() : 0f,
                    radians(g, "xMin"), radians(g, "xMax"),
                    radians(g, "zMin"), radians(g, "zMax")));
        }
        return new HairRig(bones);
    }

    private static float radians(JsonObject g, String key) {
        return (float) Math.toRadians(g.get(key).getAsFloat());
    }
}
