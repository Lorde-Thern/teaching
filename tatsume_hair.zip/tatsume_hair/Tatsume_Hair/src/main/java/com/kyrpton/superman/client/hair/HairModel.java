package com.kyrpton.superman.client.hair;

import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.kyrpton.superman.Superman;

import net.minecraft.resources.Identifier;
import net.minecraft.server.packs.resources.ResourceManager;

/**
 * A hair style: the OBJ mesh, its texture and its physics rig, loaded together.
 *
 * <p>Files, under {@code assets/superman/}:
 * <ul>
 *   <li>{@code models/hair/<name>.obj}</li>
 *   <li>{@code models/hair/<name>_rig.json}</li>
 *   <li>{@code textures/entity/hair/<name>.png}</li>
 * </ul>
 *
 * <p>Bones are stored parents-first, so physics and rendering can walk them in one pass.
 */
public final class HairModel {
    /** One drawable block. {@code bone} is its index in {@link #bones()}, or -1 if it never moves. */
    public record Part(ObjModel.Group mesh, int bone) {}

    private final Identifier texture;
    private final List<Part> parts;
    private final List<HairRig.Bone> bones;
    private final int[] parents;

    private HairModel(Identifier texture, List<Part> parts, List<HairRig.Bone> bones, int[] parents) {
        this.texture = texture;
        this.parts = parts;
        this.bones = bones;
        this.parents = parents;
    }

    public Identifier texture() { return texture; }
    public List<Part> parts() { return parts; }
    public List<HairRig.Bone> bones() { return bones; }

    /** Index of a bone's parent, or -1 for the root of a lock. Always lower than the bone's own index. */
    public int parent(int bone) { return parents[bone]; }

    public static HairModel load(ResourceManager resources, String name) throws Exception {
        Identifier objId = Identifier.fromNamespaceAndPath(Superman.MODID, "models/hair/" + name + ".obj");
        Identifier rigId = Identifier.fromNamespaceAndPath(Superman.MODID, "models/hair/" + name + "_rig.json");
        Identifier texture = Identifier.fromNamespaceAndPath(Superman.MODID, "textures/entity/hair/" + name + ".png");

        ObjModel obj;
        try (Reader r = open(resources, objId)) {
            obj = ObjModel.read(r);
        }
        HairRig rig;
        try (Reader r = open(resources, rigId)) {
            rig = HairRig.read(r);
        }

        // Put bones in parent-first order, whatever order the files list them in.
        List<String> order = new ArrayList<>();
        Map<String, Integer> index = new HashMap<>();
        for (ObjModel.Group group : obj.groups().values()) {
            addBone(group.name(), rig, order, index, 0);
        }
        List<HairRig.Bone> bones = new ArrayList<>();
        int[] parents = new int[order.size()];
        for (int i = 0; i < order.size(); i++) {
            HairRig.Bone bone = rig.bone(order.get(i));
            bones.add(bone);
            parents[i] = bone.parent() == null ? -1 : index.getOrDefault(bone.parent(), -1);
        }

        List<Part> parts = new ArrayList<>();
        for (ObjModel.Group group : obj.groups().values()) {
            parts.add(new Part(group, index.getOrDefault(group.name(), -1)));
        }
        return new HairModel(texture, List.copyOf(parts), List.copyOf(bones), parents);
    }

    private static void addBone(String name, HairRig rig, List<String> order, Map<String, Integer> index, int depth) {
        HairRig.Bone bone = rig.bone(name);
        if (bone == null || index.containsKey(name)) return;
        if (depth > 64) throw new IllegalStateException("Hair rig has a parent loop at " + name);
        if (bone.parent() != null) {
            addBone(bone.parent(), rig, order, index, depth + 1);
        }
        index.put(name, order.size());
        order.add(name);
    }

    private static Reader open(ResourceManager resources, Identifier id) throws Exception {
        var resource = resources.getResource(id)
                .orElseThrow(() -> new IllegalStateException("Missing hair file: " + id));
        return new InputStreamReader(resource.open(), StandardCharsets.UTF_8);
    }
}
