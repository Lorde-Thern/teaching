package com.kyrpton.superman.client.hair;

import java.util.function.IntPredicate;
import java.util.function.IntUnaryOperator;

import com.kyrpton.superman.Superman;

import net.minecraft.client.Minecraft;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;

/**
 * Wires the hair into the game: adds the render layer to player renderers and runs the
 * physics every client tick.
 */
@EventBusSubscriber(modid = Superman.MODID, value = Dist.CLIENT)
public final class HairClientEvents {
    /** Which hair style to load (file names under models/hair/). */
    public static final String STYLE = "messy_hair";

    /**
     * Decides which players get hair, by entity id. Everyone has it by default; replace this
     * with your own check, for example a synced player attachment.
     */
    public static IntPredicate hairFilter = id -> true;

    /**
     * Tint per player, as ARGB. White (the default) keeps the texture's own brown. The texture is
     * multiplied by this colour, so tints darken it: use a light tint for blond, for example.
     */
    public static IntUnaryOperator hairColour = id -> 0xFFFFFFFF;

    private static HairModel model;
    private static boolean failed;

    private HairClientEvents() {}

    static boolean hasHair(int entityId) {
        return hairFilter.test(entityId);
    }

    /** The loaded hair, or null if it is not loaded yet or failed to load. */
    static HairModel model() {
        if (model == null && !failed) {
            try {
                model = HairModel.load(Minecraft.getInstance().getResourceManager(), STYLE);
            } catch (Exception e) {
                failed = true; // log once, then stop trying every frame
                Superman.LOGGER.error("Could not load hair model '{}'", STYLE, e);
            }
        }
        return model;
    }

    /** Drops the loaded hair so it is read again from the resource packs (call after F3+T). */
    public static void reload() {
        model = null;
        failed = false;
        HairPhysics.clear();
    }

    @SubscribeEvent
    static void onAddLayers(EntityRenderersEvent.AddLayers event) {
        reload(); // renderers are rebuilt on resource reload, so the hair is re-read too
        for (var skin : event.getSkins()) {
            var renderer = event.getPlayerRenderer(skin);
            if (renderer != null) {
                renderer.addLayer(new HairLayer(renderer));
            }
        }
    }

    @SubscribeEvent
    static void onClientTick(ClientTickEvent.Post event) {
        var level = Minecraft.getInstance().level;
        if (level == null) {
            HairPhysics.clear();
            return;
        }
        HairModel hair = model();
        if (hair == null) return;
        HairPhysics.tick(level.players().stream().filter(p -> hasHair(p.getId())).toList(), hair);
    }
}
