package com.kyrpton.superman.client.hair;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Player;

/**
 * Spring physics for hair, run once per client tick for every player that has hair.
 *
 * <p>Each lock is a chain of bones. Every bone swings around its pivot on two axes, X (front and
 * back) and Z (side to side), relative to its parent. A damped spring pulls each bone toward a
 * target angle:
 * <ul>
 *   <li>moving makes the lock trail behind ({@code drag});</li>
 *   <li>tilting the head, or a parent bone swinging, makes it hang toward the ground ({@code gravity});</li>
 *   <li>turning or speeding up pushes it, so it overshoots and settles ({@code inertia});</li>
 *   <li>when a parent bone speeds up, the child lags behind it, so motion ripples down the lock ({@code whip}).</li>
 * </ul>
 * Each bone is then clamped to limits that keep it out of the head.
 *
 * <p>Sign conventions, Minecraft model space (+Y down, -Z front, +X character's left): a positive
 * X angle swings the tip of a hanging lock backward; a positive Z angle swings it toward the
 * character's right.
 */
public final class HairPhysics {
    private static final float SPEED_TO_ANGLE = 2.0f; // blocks per tick -> radians
    private static final float TURN_PUSH = 0.25f;
    private static final float FALL_LIFT = 1.2f;      // falling fast lifts the hair a little

    private static final Map<Integer, PlayerHair> PLAYERS = new HashMap<>();

    private HairPhysics() {}

    /** Called once per client tick with every player that should have hair. */
    public static void tick(List<? extends Player> players, HairModel model) {
        if (model == null) return;
        Set<Integer> seen = new HashSet<>();
        for (Player player : players) {
            seen.add(player.getId());
            PlayerHair hair = PLAYERS.get(player.getId());
            if (hair == null || hair.x.length != model.bones().size()) {
                hair = new PlayerHair(model.bones().size());
                PLAYERS.put(player.getId(), hair);
            }
            hair.tick(player, model);
        }
        PLAYERS.keySet().retainAll(seen); // forget players that left view
    }

    /** Front/back swing of a bone, relative to its parent, blended between ticks. */
    public static float angleX(int entityId, int bone, float partialTick) {
        PlayerHair h = PLAYERS.get(entityId);
        return h == null || bone >= h.x.length ? 0f : Mth.lerp(partialTick, h.prevX[bone], h.x[bone]);
    }

    /** Side-to-side swing of a bone, relative to its parent, blended between ticks. */
    public static float angleZ(int entityId, int bone, float partialTick) {
        PlayerHair h = PLAYERS.get(entityId);
        return h == null || bone >= h.z.length ? 0f : Mth.lerp(partialTick, h.prevZ[bone], h.z[bone]);
    }

    public static void clear() {
        PLAYERS.clear();
    }

    private static final class PlayerHair {
        final float[] x, z, prevX, prevZ, velX, velZ, accX, accZ, totalX;
        double lastX, lastY, lastZ;
        float lastYaw, lastForward, lastLeft;
        boolean first = true;
        int age;

        PlayerHair(int n) {
            x = new float[n]; z = new float[n];
            prevX = new float[n]; prevZ = new float[n];
            velX = new float[n]; velZ = new float[n];
            accX = new float[n]; accZ = new float[n];
            totalX = new float[n];
        }

        void tick(Player player, HairModel model) {
            age++;
            float yaw = player.getYHeadRot();
            if (first) {
                lastX = player.getX(); lastY = player.getY(); lastZ = player.getZ();
                lastYaw = yaw;
                first = false;
            }

            // Movement in the head's frame. Yaw 0 faces +Z; the character's left is +X.
            double dx = player.getX() - lastX, dy = player.getY() - lastY, dz = player.getZ() - lastZ;
            float yawRad = yaw * Mth.DEG_TO_RAD;
            float forward = (float) (-dx * Mth.sin(yawRad) + dz * Mth.cos(yawRad));
            float left = (float) (dx * Mth.cos(yawRad) + dz * Mth.sin(yawRad));
            float accelForward = forward - lastForward;
            float accelLeft = left - lastLeft;
            float turn = Mth.wrapDegrees(yaw - lastYaw) * Mth.DEG_TO_RAD; // > 0 = turning right
            float pitch = player.getXRot() * Mth.DEG_TO_RAD;               // > 0 = looking down
            float lift = (float) Math.min(0, dy) * FALL_LIFT;              // < 0 while falling

            lastX = player.getX(); lastY = player.getY(); lastZ = player.getZ();
            lastYaw = yaw; lastForward = forward; lastLeft = left;

            List<HairRig.Bone> bones = model.bones();
            for (int i = 0; i < bones.size(); i++) { // parents always come before children
                HairRig.Bone b = bones.get(i);
                int parent = model.parent(i);
                float parentTotal = parent >= 0 ? totalX[parent] : 0f;

                prevX[i] = x[i];
                prevZ[i] = z[i];

                float sway = 0.03f * Mth.sin(age * 0.08f + i * 1.7f);
                float targetX = b.drag() * (forward * SPEED_TO_ANGLE + lift)
                        - b.gravity() * (pitch + parentTotal) + sway;
                float targetZ = b.drag() * left * SPEED_TO_ANGLE + sway * 0.5f;
                float pushX = b.inertia() * accelForward * SPEED_TO_ANGLE;
                float pushZ = b.inertia() * (accelLeft * SPEED_TO_ANGLE - turn * TURN_PUSH);
                if (parent >= 0) {
                    pushX -= b.whip() * accX[parent];
                    pushZ -= b.whip() * accZ[parent];
                }

                float newVelX = velX[i] + b.stiffness() * (targetX - x[i]) - b.damping() * velX[i] + pushX;
                float newVelZ = velZ[i] + b.stiffness() * (targetZ - z[i]) - b.damping() * velZ[i] + pushZ;
                accX[i] = newVelX - velX[i];
                accZ[i] = newVelZ - velZ[i];
                velX[i] = newVelX;
                velZ[i] = newVelZ;
                x[i] += velX[i];
                z[i] += velZ[i];

                if (x[i] < b.xMin() || x[i] > b.xMax()) { x[i] = Mth.clamp(x[i], b.xMin(), b.xMax()); velX[i] = 0; }
                if (z[i] < b.zMin() || z[i] > b.zMax()) { z[i] = Mth.clamp(z[i], b.zMin(), b.zMax()); velZ[i] = 0; }

                totalX[i] = parentTotal + x[i];
            }
        }
    }
}
